package com.clarkcraft;

import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.block.PillarBlock;
import net.minecraft.block.TintedParticleLeavesBlock;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Function;

public final class ModBlocks {
	public static final List<Item> ITEMS = new ArrayList<>();

	// رومانية
	public static final Block ROMAN_MARBLE = reg("roman_marble", Block::new,
			AbstractBlock.Settings.create().mapColor(MapColor.WHITE).strength(1.5f, 6.0f).sounds(BlockSoundGroup.STONE));
	public static final Block ROMAN_MARBLE_BRICKS = reg("roman_marble_bricks", Block::new,
			AbstractBlock.Settings.create().mapColor(MapColor.WHITE).strength(1.5f, 6.0f).sounds(BlockSoundGroup.STONE));
	public static final Block ROMAN_ROOF_TILES = reg("roman_roof_tiles", Block::new,
			AbstractBlock.Settings.create().mapColor(MapColor.ORANGE).strength(1.2f, 4.0f).sounds(BlockSoundGroup.STONE));

	// فرعونية
	public static final Block PHARAOH_BRICKS = reg("pharaoh_bricks", Block::new,
			AbstractBlock.Settings.create().mapColor(MapColor.YELLOW).strength(1.5f, 6.0f).sounds(BlockSoundGroup.STONE));
	public static final Block PHARAOH_GOLD = reg("pharaoh_gold", Block::new,
			AbstractBlock.Settings.create().mapColor(MapColor.GOLD).strength(3.0f, 6.0f).sounds(BlockSoundGroup.METAL));
	public static final Block HIEROGLYPH_BLOCK = reg("hieroglyph_block", Block::new,
			AbstractBlock.Settings.create().mapColor(MapColor.YELLOW).strength(1.5f, 6.0f).sounds(BlockSoundGroup.STONE));

	// شجرة الزيتون
	public static final Block OLIVE_LOG = reg("olive_log", PillarBlock::new,
			AbstractBlock.Settings.create().mapColor(MapColor.BROWN).strength(2.0f).sounds(BlockSoundGroup.WOOD));
	public static final Block OLIVE_PLANKS = reg("olive_planks", Block::new,
			AbstractBlock.Settings.create().mapColor(MapColor.BROWN).strength(2.0f, 3.0f).sounds(BlockSoundGroup.WOOD));
	public static final Block OLIVE_LEAVES = reg("olive_leaves", s -> new TintedParticleLeavesBlock(0.01f, s), leaves());

	// شجرة النخيل
	public static final Block PALM_LOG = reg("palm_log", PillarBlock::new,
			AbstractBlock.Settings.create().mapColor(MapColor.TERRACOTTA_YELLOW).strength(2.0f).sounds(BlockSoundGroup.WOOD));
	public static final Block PALM_PLANKS = reg("palm_planks", Block::new,
			AbstractBlock.Settings.create().mapColor(MapColor.TERRACOTTA_YELLOW).strength(2.0f, 3.0f).sounds(BlockSoundGroup.WOOD));
	public static final Block PALM_LEAVES = reg("palm_leaves", s -> new TintedParticleLeavesBlock(0.01f, s), leaves());

	private static AbstractBlock.Settings leaves() {
		return AbstractBlock.Settings.create().mapColor(MapColor.GREEN).strength(0.2f).ticksRandomly()
				.sounds(BlockSoundGroup.GRASS).nonOpaque()
				.allowsSpawning((state, world, pos, type) -> false)
				.suffocates((state, world, pos) -> false)
				.blockVision((state, world, pos) -> false)
				.solidBlock((state, world, pos) -> false);
	}

	private static Block reg(String id, Function<AbstractBlock.Settings, Block> factory, AbstractBlock.Settings settings) {
		Identifier identifier = Identifier.of(ClarkCraft.MOD_ID, id);
		RegistryKey<Block> blockKey = RegistryKey.of(RegistryKeys.BLOCK, identifier);
		Block block = Registry.register(Registries.BLOCK, blockKey, factory.apply(settings.registryKey(blockKey)));
		RegistryKey<Item> itemKey = RegistryKey.of(RegistryKeys.ITEM, identifier);
		Item item = Registry.register(Registries.ITEM, itemKey,
				new BlockItem(block, new Item.Settings().registryKey(itemKey).useBlockPrefixedTranslationKey()));
		ITEMS.add(item);
		return block;
	}

	public static void init() {
	}

	private ModBlocks() {
	}
}
