package com.clarkcraft;

import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** يمنع اللاعبين من دخول المناطق إلا بكرت + موافقتك. */
public final class ZoneGuard {
	private static final Map<UUID, double[]> LAST_SAFE = new HashMap<>();

	public static void register() {
		ServerTickEvents.END_WORLD_TICK.register(ZoneGuard::tick);
	}

	private static void tick(ServerWorld world) {
		if (world.getTime() % 4 != 0 || ZoneManager.data.zones.isEmpty()) {
			return;
		}
		String dim = world.getRegistryKey().getValue().toString();
		for (ServerPlayerEntity player : world.getPlayers()) {
			check(player, dim);
		}
	}

	private static void check(ServerPlayerEntity player, String dim) {
		if (player.isCreative() || player.isSpectator()
				|| ZoneManager.isAdminName(player.getName().getString())) {
			return;
		}
		double x = player.getX(), y = player.getY(), z = player.getZ();
		for (ZoneManager.Zone zone : ZoneManager.data.zones) {
			if (!zone.contains(dim, x, y, z)) {
				continue;
			}
			Item cardItem = ModItems.byName(zone.card);
			boolean allowed = zone.allowed.contains(player.getUuidAsString());
			boolean hasCard = hasCard(player, cardItem);
			if (allowed && hasCard) {
				continue; // مسموح
			}
			if (!allowed) {
				player.sendMessage(Text.literal("§c⛔ ممنوع الدخول! الإدارة لم تسمح لك بدخول هذه المنطقة."), true);
			} else {
				player.sendMessage(Text.literal("§c⛔ ممنوع الدخول! تحتاج حمل: ").append(cardItem.getName()), true);
			}
			pushOut(player, zone, x, y, z);
			return;
		}
		LAST_SAFE.put(player.getUuid(), new double[]{x, y, z});
	}

	private static boolean hasCard(ServerPlayerEntity player, Item card) {
		var inv = player.getInventory();
		for (int i = 0; i < inv.size(); i++) {
			ItemStack stack = inv.getStack(i);
			if (!stack.isEmpty() && stack.isOf(card)) {
				return true;
			}
		}
		return false;
	}

	private static void pushOut(ServerPlayerEntity player, ZoneManager.Zone zone, double x, double y, double z) {
		double[] safe = LAST_SAFE.get(player.getUuid());
		if (safe != null && !zone.contains(zone.dimension, safe[0], safe[1], safe[2])) {
			player.requestTeleport(safe[0], safe[1], safe[2]);
			return;
		}
		// لا يوجد مكان آمن محفوظ: أقرب حافة أفقية
		double toWest = x - zone.x1, toEast = zone.x2 + 1 - x;
		double toNorth = z - zone.z1, toSouth = zone.z2 + 1 - z;
		double min = Math.min(Math.min(toWest, toEast), Math.min(toNorth, toSouth));
		if (min == toWest) {
			x = zone.x1 - 2;
		} else if (min == toEast) {
			x = zone.x2 + 3;
		} else if (min == toNorth) {
			z = zone.z1 - 2;
		} else {
			z = zone.z2 + 3;
		}
		player.requestTeleport(x, y + 1, z);
	}

	private ZoneGuard() {
	}
}
