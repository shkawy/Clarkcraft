package com.clarkcraft;

import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.util.Rarity;

import java.util.ArrayList;
import java.util.List;

public final class ModItems {
	public static final List<Item> CARDS = new ArrayList<>();

	public static final Item PHARAOH_CARD = card("pharaoh_card");
	public static final Item ROMAN_CARD = card("roman_card");
	public static final Item GOLDEN_CARD = card("golden_card");

	private static Item card(String id) {
		RegistryKey<Item> key = RegistryKey.of(RegistryKeys.ITEM, Identifier.of(ClarkCraft.MOD_ID, id));
		Item item = Registry.register(Registries.ITEM, key,
				new Item(new Item.Settings().registryKey(key).maxCount(1).rarity(Rarity.EPIC)));
		CARDS.add(item);
		return item;
	}

	/** يحوّل اسم الكرت في الأوامر إلى العنصر. */
	public static Item byName(String name) {
		return switch (name) {
			case "pharaoh" -> PHARAOH_CARD;
			case "roman" -> ROMAN_CARD;
			case "golden" -> GOLDEN_CARD;
			default -> null;
		};
	}

	public static void init() {
	}

	private ModItems() {
	}
}
